﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("AtlyssArchipelagoWIP")]
[assembly: AssemblyDescription("Archipelago integration for Atlyss")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("AtlyssArchipelagoWIP")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("80bfea1c-ae53-460f-bbc2-09bb8d627051")]
[assembly: AssemblyVersion("0.7.0.0")]
[assembly: AssemblyFileVersion("0.7.0.0")]